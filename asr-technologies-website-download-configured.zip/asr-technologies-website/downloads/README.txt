Optional: copy MediVyapar-Setup-1_1_0.exe into this folder and set
DOWNLOAD_URL = 'downloads/MediVyapar-Setup-1_1_0.exe' in js/config.js
(only if your hosting allows large files; GitHub Releases is recommended).
