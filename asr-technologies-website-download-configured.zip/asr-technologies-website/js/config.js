// ===== ASR Technologies site settings =====
// Opens the MediVyapar download page on Google Drive.
var DOWNLOAD_URL = 'https://drive.google.com/file/d/1F0G-O4RcUddXM81AUjQcE2OVPw4tcncU/view?usp=sharing';
