document.getElementById('y').textContent=new Date().getFullYear();
var mb=document.getElementById('mb'),mn=document.getElementById('menu');
mb.onclick=function(){mn.classList.toggle('open')};
mn.onclick=function(e){if(e.target.tagName==='A')mn.classList.remove('open')};
document.getElementById('f').onsubmit=function(ev){
ev.preventDefault();var d=new FormData(this);
var t='Hello ASR Technologies, I want the 30-day free trial.\n'+
'Name: '+d.get('n')+'\nPhone: '+d.get('p')+'\nEmail: '+(d.get('e')||'-')+
'\nBusiness: '+d.get('b')+'\nSoftware: '+d.get('s')+'\nMessage: '+(d.get('m')||'-');
document.getElementById('ok').style.display='block';
window.open('https://wa.me/919341858573?text='+encodeURIComponent(t),'_blank');
};
var KEY='asr_mv_reg',rf=document.getElementById('rf'),ds=document.getElementById('ds');
function step(u){if(u){document.getElementById('dn').textContent=u.n.split(' ')[0];rf.style.display='none';ds.classList.add('show')}else{rf.style.display='';ds.classList.remove('show')}}
function load(){try{return JSON.parse(localStorage.getItem(KEY))}catch(x){return null}}
step(load());
rf.onsubmit=function(ev){ev.preventDefault();
var d=Object.fromEntries(new FormData(rf)),er=document.getElementById('re');
if(!d.n.trim()||!d.c.trim()||!d.s.trim()){er.textContent='Please fill in all required fields.';return}
if(!/^\S+@\S+\.\S+$/.test(d.e)){er.textContent='Enter a valid email address.';return}
if(!/^(\+91|0)?[6-9]\d{9}$/.test(d.p.replace(/[\s-]/g,''))){er.textContent='Enter a valid 10-digit mobile number.';return}
if(!/^\d{6}$/.test(d.z)){er.textContent='Pincode must be 6 digits.';return}
er.textContent='';try{localStorage.setItem(KEY,JSON.stringify(d))}catch(x){}
step(d);ds.scrollIntoView({behavior:'smooth',block:'center'})};
document.getElementById('ed').onclick=function(){try{localStorage.removeItem(KEY)}catch(x){}rf.reset();step(null)};
document.getElementById('db').onclick=function(){var d=load()||{};
if(DOWNLOAD_URL){window.open(DOWNLOAD_URL,'_blank')}
else{var t='Hello ASR Technologies, please send the MediVyapar download link.\nName: '+(d.n||'')+'\nEmail: '+(d.e||'')+'\nPhone: '+(d.p||'')+'\nAddress: '+[d.a,d.c,d.s,d.z].filter(Boolean).join(', ');
window.open('https://wa.me/919341858573?text='+encodeURIComponent(t),'_blank')}};
